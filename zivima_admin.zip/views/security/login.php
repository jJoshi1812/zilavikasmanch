<div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name">Zila</h1>

            </div>
            <h3>Welcome to Zila Vikas Manch</h3>

            <form class="m-t" role="form" action="admin_dashboard.html">
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Username" required="">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">Login</button>

                <a href="#"><small>Forgot password?</small></a>

            </form>
            <p class="m-t"> <small>District Development Portal &copy; 2018</small> </p>
        </div>
    </div>